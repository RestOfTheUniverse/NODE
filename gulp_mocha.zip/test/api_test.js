var assert = require('assert');
var Customers = require('../model/customer');
var app = require('../app');
var request  = require('supertest');
var should = require('should');

describe("Customer RESTful services", function() {

	it("should read 4 Customers", function(done){
		var records;
		request(app).get("/api").end(function(err, res) {
			should.not.exist(err);
			records = res.body;
			assert.equal(6,records.length);
			done();
		});
	});
});
