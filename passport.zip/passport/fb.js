// facebook app settings
module.exports = {
	'appID' : '',
	'appSecret' : '',
	'callbackUrl' : 'http://localhost:3000/login/facebook/callback'
}