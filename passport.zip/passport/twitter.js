// twitter app settings
module.exports = {
	'apikey' : '',
	'apisecret' : '',
	'callbackUrl' : 'http://127.0.0.1:3000/login/twitter/callback'
}